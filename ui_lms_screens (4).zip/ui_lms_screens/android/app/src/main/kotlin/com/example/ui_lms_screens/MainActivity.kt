package com.example.ui_lms_screens

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
