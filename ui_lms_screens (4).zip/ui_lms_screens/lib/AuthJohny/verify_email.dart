// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';

// class VerifyEmailPage extends StatefulWidget {
//   const VerifyEmailPage({Key? key}) : super(key: key);

//   @override
//   State<VerifyEmailPage> createState() => _VerifyEmailPageState();
// }

// class _VerifyEmailPageState extends State<VerifyEmailPage> {
//   bool isEmailVerified = false;
//   Timer? timer;

//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//     isEmailVerified = FirebaseAuth.instance.currentUser;
//     if (!isEmailVerified) {
//       sendVerificationEmail();
//       timer = Timer.periodic(
//         Duration(seconds: 4),
//         (_) => checkEmailVerified(),
//       );
//     }
//   }

//   @override
//   void dispose() {
//     timer?.cancel();
//     super.dispose();
//   }

//   Future sendVerificationEmail() async {
//     try {
//       final user = FirebaseAuth.instance.currentUser!;
//       await user.sendEmailVerification();
//     } catch (e) {}
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Container();
//   }
// }
