// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';

// import 'package:ui_lms_screens/Auth_geekyshow/login.dart';
// import 'package:ui_lms_screens/Auth_geekyshow/user/change_password.dart';
// import 'package:ui_lms_screens/Auth_geekyshow/user/dashboard.dart';
// import 'package:ui_lms_screens/Auth_geekyshow/user/profile.dart';
// import 'package:ui_lms_screens/screens/Featured_courseScreen.dart';
// import 'package:ui_lms_screens/screens/saved.dart';

// class UserMain extends StatefulWidget {
//   UserMain({Key? key}) : super(key: key);

//   @override
//   _UserMainState createState() => _UserMainState();
// }

// class _UserMainState extends State<UserMain> {
//   int _selectedIndex = 0;
//   static List<Widget> _widgetOptions = <Widget>[
//     Featured(),
//     Saved_Videos(),
//     Profile(),
//     ChangePassword(),
//   ];
//   void _onItemTapped(int index) {
//     setState(() {
//       _selectedIndex = index;
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Row(
//           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//           children: [
//             Text("Welcome User"),
//             ElevatedButton(
//               onPressed: () async => {
//                 await FirebaseAuth.instance.signOut(),
//                 Navigator.pushAndRemoveUntil(
//                     context,
//                     MaterialPageRoute(
//                       builder: (context) => Login(),
//                     ),
//                     (route) => false)
//               },
//               child: Text('Logout'),
//               style: ElevatedButton.styleFrom(primary: Colors.blueGrey),
//             )
//           ],
//         ),
//       ),
//       body: _widgetOptions.elementAt(_selectedIndex),
//       bottomNavigationBar: BottomNavigationBar(
//         //backgroundColor: Colors.blueAccent,
//         items: const <BottomNavigationBarItem>[
//           BottomNavigationBarItem(
//             icon: Icon(Icons.home),
//             label: 'Home',
//           ),
//           BottomNavigationBarItem(icon: Icon(Icons.favorite), label: 'Saved'),
//           BottomNavigationBarItem(
//             icon: Icon(Icons.person),
//             label: 'My Profile',
//           ),
//           BottomNavigationBarItem(
//             icon: Icon(Icons.settings),
//             label: 'Change Password',
//           ),
//         ],
//         currentIndex: _selectedIndex,

//         selectedItemColor: Colors.red,
//         onTap: _onItemTapped,
//         backgroundColor: Colors.black,
//       ),
//     );
//   }
// }

// import 'package:flutter/material.dart';
// import 'package:ui_lms_screens/screens/Account.dart';
// import 'package:ui_lms_screens/screens/Featured_courseScreen.dart';
// import 'package:ui_lms_screens/screens/downloaded.dart';
// import 'package:ui_lms_screens/screens/saved.dart';

// class BottomNav extends StatefulWidget {
//   const BottomNav({Key? key}) : super(key: key);

//   @override
//   State<BottomNav> createState() => _BottomNavState();
// }

// class _BottomNavState extends State<BottomNav> {
//   int _selectedScreenIndex = 0;
//   final List _screens = [
//     {"screen": Featured(), "title": "Home"},
//     {"screen": Saved_Videos(), "title": "Saved"},
//     {"screen": Downloaded_Videos(), "title": "Downloaded"},
//     {"screen": Account(), "title": "Profile"}
//   ];

//   void _selectScreen(int index) {
//     setState(() {
//       _selectedScreenIndex = index;
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text(_screens[_selectedScreenIndex]["title"]),
//       ),
//       body: _screens[_selectedScreenIndex]["screen"],
//       bottomNavigationBar: BottomNavigationBar(
//         backgroundColor: Colors.black12,
//         currentIndex: _selectedScreenIndex,
//         onTap: _selectScreen,
//         items: [
//           BottomNavigationBarItem(
//             icon: Icon(Icons.home, color: Colors.blueAccent, size: 30),
//             label: 'Home',
//           ),
//           BottomNavigationBarItem(
//               icon: Icon(
//                 Icons.bookmark_outline,
//                 color: Colors.blueAccent,
//                 size: 30,
//               ),
//               label: "Saved"),
//           BottomNavigationBarItem(
//               icon: Icon(
//                 Icons.download_outlined,
//                 color: Colors.blueAccent,
//                 size: 30,
//               ),
//               label: 'Downloaded'),
//           BottomNavigationBarItem(
//               icon: Icon(
//                 Icons.person,
//                 color: Colors.blueAccent,
//                 size: 30,
//               ),
//               label: 'Profile'),
//         ],
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:ui_lms_screens/Auth_geekyshow/user/change_password.dart';
import 'package:ui_lms_screens/Auth_geekyshow/user/profile.dart';
import 'package:ui_lms_screens/screens/Account.dart';
import 'package:ui_lms_screens/screens/Course_home.dart';
import 'package:ui_lms_screens/screens/Featured_courseScreen.dart';
import 'package:ui_lms_screens/screens/HomePage.dart';
import 'package:ui_lms_screens/screens/courses_home_multiplestreams.dart';
import 'package:ui_lms_screens/screens/data_controller.dart';
import 'package:ui_lms_screens/screens/downloaded.dart';
import 'package:ui_lms_screens/screens/saved.dart';

class BottomNav extends StatefulWidget {
  const BottomNav({Key? key}) : super(key: key);

  @override
  State<BottomNav> createState() => _BottomNavState();
}

class _BottomNavState extends State<BottomNav>
    with SingleTickerProviderStateMixin {
  //String title = 'BottomNavigationBar';

  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    super.dispose();
    _tabController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   title: Text(title),
      //   centerTitle: true,
      // ),
      body: TabBarView(
        children: [
          //Featured(),
          // Home_Courses(),
          //Home_multi_courses(),
          Home(),
          Saved_Videos(),
          Profile(),
          ChangePassword(),
        ],
        // If you want to disable swiping in tab the use below code
        physics: NeverScrollableScrollPhysics(),
        controller: _tabController,
      ),
      bottomNavigationBar: Container(
        color: Colors.black,
        padding: EdgeInsets.all(16.0),
        child: ClipRRect(
          borderRadius: BorderRadius.all(
            Radius.circular(46.0),
          ),
          child: Container(
            color: Colors.cyan,
            child: TabBar(
              labelColor: Colors.black,
              unselectedLabelColor: Colors.white,
              labelStyle: TextStyle(fontSize: 14.0),
              indicator: UnderlineTabIndicator(
                borderSide: BorderSide(color: Colors.black54, width: 0.0),
                insets: EdgeInsets.fromLTRB(50.0, 0.0, 50.0, 40.0),
              ),
              //For Indicator Show and Customization
              indicatorColor: Colors.black54,
              tabs: <Widget>[
                Tab(
                  icon: Icon(
                    Icons.video_call,
                    size: 26.0,
                  ),
                  text: 'Home',
                ),
                Tab(
                  icon: Icon(
                    Icons.bookmark_outline,
                    size: 26.0,
                  ),
                  text: 'Saved',
                ),
                Tab(
                  icon: Icon(
                    Icons.download_rounded,
                    size: 26.0,
                  ),
                  text: 'Profile',
                ),
                Tab(
                  icon: Icon(
                    Icons.person,
                    size: 26.0,
                  ),
                  text: 'Change password',
                ),
              ],
              controller: _tabController,
            ),
          ),
        ),
      ),
    );
  }
}
