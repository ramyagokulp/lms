// import 'package:flutter/material.dart';
// import 'package:ui_lms_screens/screens/Account.dart';
// import 'package:ui_lms_screens/screens/Featured_courseScreen.dart';
// import 'package:ui_lms_screens/screens/downloaded.dart';
// import 'package:ui_lms_screens/screens/saved.dart';

// class BottomNav extends StatefulWidget {
//   const BottomNav({Key? key}) : super(key: key);

//   @override
//   State<BottomNav> createState() => _BottomNavState();
// }

// class _BottomNavState extends State<BottomNav> {
//   int _selectedScreenIndex = 0;
//   final List _screens = [
//     {"screen": Featured(), "title": "Home"},
//     {"screen": Saved_Videos(), "title": "Saved"},
//     {"screen": Downloaded_Videos(), "title": "Downloaded"},
//     {"screen": Account(), "title": "Profile"}
//   ];

//   void _selectScreen(int index) {
//     setState(() {
//       _selectedScreenIndex = index;
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text(_screens[_selectedScreenIndex]["title"]),
//       ),
//       body: _screens[_selectedScreenIndex]["screen"],
//       bottomNavigationBar: BottomNavigationBar(
//         backgroundColor: Colors.black12,
//         currentIndex: _selectedScreenIndex,
//         onTap: _selectScreen,
//         items: [
//           BottomNavigationBarItem(
//             icon: Icon(Icons.home, color: Colors.blueAccent, size: 30),
//             label: 'Home',
//           ),
//           BottomNavigationBarItem(
//               icon: Icon(
//                 Icons.bookmark_outline,
//                 color: Colors.blueAccent,
//                 size: 30,
//               ),
//               label: "Saved"),
//           BottomNavigationBarItem(
//               icon: Icon(
//                 Icons.download_outlined,
//                 color: Colors.blueAccent,
//                 size: 30,
//               ),
//               label: 'Downloaded'),
//           BottomNavigationBarItem(
//               icon: Icon(
//                 Icons.person,
//                 color: Colors.blueAccent,
//                 size: 30,
//               ),
//               label: 'Profile'),
//         ],
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:ui_lms_screens/screens/Account.dart';
import 'package:ui_lms_screens/screens/Featured_courseScreen.dart';
import 'package:ui_lms_screens/screens/downloaded.dart';
import 'package:ui_lms_screens/screens/saved.dart';

class BottomNav extends StatefulWidget {
  const BottomNav({Key? key}) : super(key: key);

  @override
  State<BottomNav> createState() => _BottomNavState();
}

class _BottomNavState extends State<BottomNav>
    with SingleTickerProviderStateMixin {
  //String title = 'BottomNavigationBar';

  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    super.dispose();
    _tabController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   title: Text(title),
      //   centerTitle: true,
      // ),
      body: TabBarView(
        children: <Widget>[
          Featured(),
          Saved_Videos(),
          Downloaded_Videos(),
          Account(),
        ],
        // If you want to disable swiping in tab the use below code
        physics: NeverScrollableScrollPhysics(),
        controller: _tabController,
      ),
      bottomNavigationBar: Container(
        color: Colors.black,
        padding: EdgeInsets.all(16.0),
        child: ClipRRect(
          borderRadius: BorderRadius.all(
            Radius.circular(50.0),
          ),
          child: Container(
            color: Colors.lightBlueAccent,
            child: TabBar(
              labelColor: Colors.black,
              unselectedLabelColor: Colors.white,
              labelStyle: TextStyle(fontSize: 20.0),
              indicator: UnderlineTabIndicator(
                borderSide: BorderSide(color: Colors.black54, width: 0.0),
                insets: EdgeInsets.fromLTRB(50.0, 0.0, 50.0, 40.0),
              ),
              //For Indicator Show and Customization
              indicatorColor: Colors.black54,
              tabs: <Widget>[
                Tab(
                  icon: Icon(
                    Icons.video_call,
                    size: 24.0,
                  ),
                  text: 'Home',
                ),
                Tab(
                  icon: Icon(
                    Icons.bookmark_outline,
                    size: 24.0,
                  ),
                  text: 'Saved',
                ),
                Tab(
                  icon: Icon(
                    Icons.download_rounded,
                    size: 24.0,
                  ),
                  text: 'Downloaded',
                ),
                Tab(
                  icon: Icon(
                    Icons.person,
                    size: 24.0,
                  ),
                  text: 'Profile',
                ),
              ],
              controller: _tabController,
            ),
          ),
        ),
      ),
    );
  }
}
