import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:ui_lms_screens/screens/details_screen.dart';

//***  CyberSecurity ***//

Widget dataScience(BuildContext context) {
  return Scaffold(
    backgroundColor: Colors.black,
    body: SingleChildScrollView(
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: 25,
            ),
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Container(
                child: Container(
                  height: 150.0,
                  width: 400.0,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10.0),
                      image: DecorationImage(
                          image: AssetImage('assets/images/sale1.png'))),
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Container(
                height: 80.0,
                width: 400,
                color: Colors.blueAccent,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text('Courses on sale',
                        style: TextStyle(color: Colors.white, fontSize: 20.0)),
                    SizedBox(height: 6),
                    Text('1 Day Left',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 22.0,
                            fontWeight: FontWeight.bold))
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: EdgeInsets.only(left: 8.0),
              child: Text(
                'DataScience',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 22.0,
                    fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(
                height: 300.0,
                width: 450.0,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  // itemCount: snapshot.data!.length,
                  itemCount: 6,
                  itemBuilder: (BuildContext context, int index) {
                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Details_Screen()));
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Container(
                                height: 100.0,
                                width: 200.0,
                                decoration: BoxDecoration(
                                    image: DecorationImage(
                                        fit: BoxFit.fitWidth,
                                        image: AssetImage(
                                            'assets/images/datascience.png'))),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 8.0),
                                child: Container(
                                  constraints: BoxConstraints(maxWidth: 220.0),
                                  child: Text(
                                    'DataScience',
                                    style: TextStyle(
                                        color: Colors.white, fontSize: 18.0),
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 8.0),
                                child: Text(
                                  'Author',
                                  style: TextStyle(
                                      color: Colors.grey.shade600,
                                      fontSize: 12.0),
                                ),
                              ),
                              Row(
                                children: [
                                  Icon(Icons.star, color: Colors.yellowAccent),
                                  Icon(Icons.star, color: Colors.yellowAccent),
                                  Icon(Icons.star, color: Colors.yellowAccent),
                                  Icon(Icons.star, color: Colors.yellowAccent),
                                  Icon(Icons.star, color: Colors.yellowAccent),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 4.0),
                                    child: Text(
                                      'ratings',
                                      style: TextStyle(
                                          color: Colors.grey.shade600,
                                          fontSize: 16.0),
                                    ),
                                  ),
                                ],
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 4.0),
                                child: Row(
                                  children: [
                                    Icon(Icons.currency_rupee,
                                        color: Colors.white),
                                    Text(
                                      'price',
                                      style: TextStyle(
                                          color: Colors.white, fontSize: 22.0),
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 4.0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    color: Colors.yellow,
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Text('Bestseller',
                                        style: TextStyle(
                                            color: Colors.brown,
                                            fontWeight: FontWeight.bold)),
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                )),
            SizedBox(height: 15),
            Padding(
              padding: EdgeInsets.only(left: 10),
              child: Text(
                'CyberSecurity',
                style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              ),
            ),
            Container(
              padding: EdgeInsets.all(8.0),
              child: cyberSecurity(context),
            ),
            SizedBox(
              height: 23,
            ),
            Padding(
              padding: EdgeInsets.only(left: 10),
              child: Text(
                'Selenium',
                style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              ),
            ),
            Container(
              child: selenium(context),
            ),
            SizedBox(
              height: 22,
            ),
            Padding(
              padding: EdgeInsets.only(left: 8),
              child: Text(
                'DevOps',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 22),
              ),
            ),
            Container(
              child: devops(context),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: EdgeInsets.only(left: 10),
              child: Text(
                'WebDevelopment',
                style: TextStyle(
                    fontSize: 22,
                    color: Colors.white,
                    fontWeight: FontWeight.bold),
              ),
            ),
            Container(
              child: webDevelopment(context),
            ),
            SizedBox(
              height: 15,
            ),
            Padding(
              padding: EdgeInsets.only(left: 10),
              child: Text(
                'SQL',
                style: TextStyle(
                    fontSize: 22,
                    color: Colors.white,
                    fontWeight: FontWeight.bold),
              ),
            ),
            Container(
              child: sql(context),
            )
          ]),
    ),
  );
}

Widget cyberSecurity(BuildContext context) {
  return SizedBox(
    height: 300,
    width: 450.0,
    child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: 6,
        itemBuilder: (BuildContext context, int index) {
          return GestureDetector(
            onTap: () {
              Navigator.pushReplacement(
                  context,
                  PageTransition(
                      child: Details_Screen(),
                      type: PageTransitionType.bottomToTop));
            },
            child: Padding(
              padding: EdgeInsets.all(8.0),
              child: Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: 100,
                      width: 200.0,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              fit: BoxFit.fitWidth,
                              image: AssetImage(
                                  'assets/images/cybersecurity.png'))),
                    ),
                    Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Container(
                          constraints: BoxConstraints(maxWidth: 220),
                          child: Text(
                            'CyberSecurity',
                            style: TextStyle(fontSize: 18, color: Colors.white),
                          ),
                        )),
                    Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        'Author',
                        style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      ),
                    ),
                    Row(
                      children: [
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Padding(
                          padding: const EdgeInsets.only(left: 4.0),
                          child: Text(
                            'ratings',
                            style: TextStyle(
                                color: Colors.grey.shade600, fontSize: 16.0),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: Row(
                        children: [
                          Icon(Icons.currency_rupee, color: Colors.white),
                          Text(
                            'price',
                            style:
                                TextStyle(color: Colors.white, fontSize: 22.0),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 4.0),
                      child: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10.0),
                            color: Colors.yellow),
                        child: Padding(
                          padding: EdgeInsets.all(8),
                          child: Text(
                            "BestSeller",
                            style: TextStyle(
                                color: Colors.brown,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          );
        }),
  );
}

// *** Selenium *** //

Widget selenium(BuildContext context) {
  return SizedBox(
    height: 300,
    width: 450.0,
    child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: 6,
        itemBuilder: (BuildContext context, int index) {
          return GestureDetector(
            onTap: () {
              Navigator.pushReplacement(
                  context,
                  PageTransition(
                      child: Details_Screen(),
                      type: PageTransitionType.bottomToTop));
            },
            child: Padding(
              padding: EdgeInsets.all(8.0),
              child: Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: 100,
                      width: 200.0,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              fit: BoxFit.fitWidth,
                              image: AssetImage('assets/images/selenium.png'))),
                    ),
                    Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Container(
                          constraints: BoxConstraints(maxWidth: 220),
                          child: Text(
                            'Selenium',
                            style: TextStyle(fontSize: 18, color: Colors.white),
                          ),
                        )),
                    Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        'Author',
                        style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      ),
                    ),
                    Row(
                      children: [
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Padding(
                          padding: const EdgeInsets.only(left: 4.0),
                          child: Text(
                            'ratings',
                            style: TextStyle(
                                color: Colors.grey.shade600, fontSize: 16.0),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: Row(
                        children: [
                          Icon(Icons.currency_rupee, color: Colors.white),
                          Text(
                            'price',
                            style:
                                TextStyle(color: Colors.white, fontSize: 22.0),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 4.0),
                      child: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10.0),
                            color: Colors.yellow),
                        child: Padding(
                          padding: EdgeInsets.all(8),
                          child: Text(
                            "BestSeller",
                            style: TextStyle(
                                color: Colors.brown,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          );
        }),
  );
}

// *** DevOps *** //

Widget devops(BuildContext context) {
  return SizedBox(
    height: 300,
    width: 450.0,
    child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: 6,
        itemBuilder: (BuildContext context, int index) {
          return GestureDetector(
            onTap: () {
              Navigator.pushReplacement(
                  context,
                  PageTransition(
                      child: Details_Screen(),
                      type: PageTransitionType.bottomToTop));
            },
            child: Padding(
              padding: EdgeInsets.all(8.0),
              child: Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: 100,
                      width: 200.0,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              fit: BoxFit.fitWidth,
                              image: AssetImage('assets/images/devops.png'))),
                    ),
                    Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Container(
                          constraints: BoxConstraints(maxWidth: 220),
                          child: Text(
                            'DevOps',
                            style: TextStyle(fontSize: 18, color: Colors.white),
                          ),
                        )),
                    Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        'Author',
                        style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      ),
                    ),
                    Row(
                      children: [
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Padding(
                          padding: const EdgeInsets.only(left: 4.0),
                          child: Text(
                            'ratings',
                            style: TextStyle(
                                color: Colors.grey.shade600, fontSize: 16.0),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: Row(
                        children: [
                          Icon(Icons.currency_rupee, color: Colors.white),
                          Text(
                            'price',
                            style:
                                TextStyle(color: Colors.white, fontSize: 22.0),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 4.0),
                      child: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10.0),
                            color: Colors.yellow),
                        child: Padding(
                          padding: EdgeInsets.all(8),
                          child: Text(
                            "BestSeller",
                            style: TextStyle(
                                color: Colors.brown,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          );
        }),
  );
}

// *** Web Development *** //

Widget webDevelopment(BuildContext context) {
  return SizedBox(
    height: 300,
    width: 450.0,
    child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: 6,
        itemBuilder: (BuildContext context, int index) {
          return GestureDetector(
            onTap: () {
              Navigator.pushReplacement(
                  context,
                  PageTransition(
                      child: Details_Screen(),
                      type: PageTransitionType.bottomToTop));
            },
            child: Padding(
              padding: EdgeInsets.all(8.0),
              child: Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: 100,
                      width: 200.0,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              fit: BoxFit.fitWidth,
                              image: AssetImage('assets/images/Webdev.png'))),
                    ),
                    Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Container(
                          constraints: BoxConstraints(maxWidth: 220),
                          child: Text(
                            'WebDevelopment',
                            style: TextStyle(fontSize: 18, color: Colors.white),
                          ),
                        )),
                    Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        'Author',
                        style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      ),
                    ),
                    Row(
                      children: [
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Padding(
                          padding: const EdgeInsets.only(left: 4.0),
                          child: Text(
                            'ratings',
                            style: TextStyle(
                                color: Colors.grey.shade600, fontSize: 16.0),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: Row(
                        children: [
                          Icon(Icons.currency_rupee, color: Colors.white),
                          Text(
                            'price',
                            style:
                                TextStyle(color: Colors.white, fontSize: 22.0),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 4.0),
                      child: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10.0),
                            color: Colors.yellow),
                        child: Padding(
                          padding: EdgeInsets.all(8),
                          child: Text(
                            "BestSeller",
                            style: TextStyle(
                                color: Colors.brown,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          );
        }),
  );
}

//*** SQL ***//

Widget sql(BuildContext context) {
  return SizedBox(
    height: 300,
    width: 450.0,
    child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: 6,
        itemBuilder: (BuildContext context, int index) {
          return GestureDetector(
            onTap: () {
              Navigator.pushReplacement(
                  context,
                  PageTransition(
                      child: Details_Screen(),
                      type: PageTransitionType.bottomToTop));
            },
            child: Padding(
              padding: EdgeInsets.all(8.0),
              child: Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: 100,
                      width: 200.0,
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              fit: BoxFit.fitWidth,
                              image: AssetImage('assets/images/sql.png'))),
                    ),
                    Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Container(
                          constraints: BoxConstraints(maxWidth: 220),
                          child: Text(
                            'SQL',
                            style: TextStyle(fontSize: 18, color: Colors.white),
                          ),
                        )),
                    Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        'Author',
                        style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      ),
                    ),
                    Row(
                      children: [
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Icon(Icons.star, color: Colors.yellowAccent),
                        Padding(
                          padding: const EdgeInsets.only(left: 4.0),
                          child: Text(
                            'ratings',
                            style: TextStyle(
                                color: Colors.grey.shade600, fontSize: 16.0),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 4.0),
                      child: Row(
                        children: [
                          Icon(Icons.currency_rupee, color: Colors.white),
                          Text(
                            'price',
                            style:
                                TextStyle(color: Colors.white, fontSize: 22.0),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 4.0),
                      child: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10.0),
                            color: Colors.yellow),
                        child: Padding(
                          padding: EdgeInsets.all(8),
                          child: Text(
                            "BestSeller",
                            style: TextStyle(
                                color: Colors.brown,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          );
        }),
  );
}
