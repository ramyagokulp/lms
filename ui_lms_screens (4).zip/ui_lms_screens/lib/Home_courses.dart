// import 'dart:math';

// import 'package:flutter/material.dart';

// class HomePage extends StatefulWidget {
//   const HomePage({Key? key}) : super(key: key);

//   @override
//   State<HomePage> createState() => _HomePageState();
// }

// class _HomePageState extends State<HomePage> {
//   // generate dummy data to feed the second SliverGrid
//   //final List _gridItems = List.generate(90, (i) => "Item $i");

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Learning Management System'),
//         elevation: 16,
//       ),
//       body: CustomScrollView(slivers: [
//         // SliverAppBar #1
//         SliverAppBar(
//           pinned: true,
//           backgroundColor: Colors.blueAccent,
//           expandedHeight: 200.0,
//           elevation: 1,
//           flexibleSpace: FlexibleSpaceBar(
//             background: Container(
//               color: Colors.deepOrange[200],
//               child: Icon(
//                 Icons.featured_play_list_outlined,
//                 size: 36,
//               ),
//             ),
//             title: const Text(
//               'Courses Available',
//               style: TextStyle(color: Colors.black, fontSize: 26),
//             ),
//           ),
//         ),

//         // SliverGrid #1
//         // SliverGrid.count(
//         //   crossAxisCount: 2,
//         //   mainAxisSpacing: 10.0,
//         //   crossAxisSpacing: 10.0,
//         //   childAspectRatio: 1,
//         ListView(
//           scrollDirection: Axis.horizontal,
//           children: [
//             Card(
//               color: Colors.blue[200],
//               child: Container(
//                   width: 100.00,
//                   height: 100.00,
//                   decoration: new BoxDecoration(
//                     image: new DecorationImage(
//                       image: ExactAssetImage('assets/images/flutter.png'),
//                       fit: BoxFit.fitHeight,
//                     ),
//                   ),
//                   child: Column(
//                     children: [
//                       Text(
//                         'Flutter',
//                         style: TextStyle(
//                             fontWeight: FontWeight.bold, fontSize: 18),
//                       ),
//                       Text('Flutter Mobile app development')
//                     ],
//                   )),
//             ),
//             Card(
//               color: Colors.blue[200],
//               child: Container(
//                 width: 100.00,
//                 height: 100.00,
//                 decoration: new BoxDecoration(
//                   image: new DecorationImage(
//                     image: ExactAssetImage('assets/images/datascience.png'),
//                     fit: BoxFit.fitHeight,
//                   ),
//                 ),
//                 child: Text(
//                   'DataScience',
//                   style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
//                 ),
//               ),
//             ),
//             Card(
//               color: Colors.blue[400],
//               child: Container(
//                   width: 100.00,
//                   height: 100.00,
//                   decoration: new BoxDecoration(
//                     image: new DecorationImage(
//                       image: ExactAssetImage('assets/images/devops.png'),
//                       fit: BoxFit.fitHeight,
//                     ),
//                   )),
//             ),
//             Card(
//               color: Colors.blue[600],
//               child: Container(
//                   width: 100.00,
//                   height: 100.00,
//                   decoration: new BoxDecoration(
//                     image: new DecorationImage(
//                       image: ExactAssetImage('assets/images/webdev.png'),
//                       fit: BoxFit.fitHeight,
//                     ),
//                   )),
//             ),
//             Card(
//               color: Colors.blue[100],
//               child: Container(
//                   width: 100.00,
//                   height: 100.00,
//                   decoration: new BoxDecoration(
//                     image: new DecorationImage(
//                       image: ExactAssetImage('assets/images/selenium.png'),
//                       fit: BoxFit.fitHeight,
//                     ),
//                   )),
//             ),
//             Card(
//               color: Colors.blue[600],
//               child: Container(
//                   width: 100.00,
//                   height: 100.00,
//                   decoration: new BoxDecoration(
//                     image: new DecorationImage(
//                       image: ExactAssetImage('assets/images/sql.png'),
//                       fit: BoxFit.fitHeight,
//                     ),
//                   )),
//             ),
//             Card(
//               color: Colors.blue[600],
//               child: Container(
//                   width: 100.00,
//                   height: 100.00,
//                   decoration: new BoxDecoration(
//                     image: new DecorationImage(
//                       image: ExactAssetImage('assets/images/cybersecurity.png'),
//                       fit: BoxFit.fitHeight,
//                     ),
//                   )),
//             ),
//           ],
//         ),

//         // Just add some padding
//         const SliverPadding(padding: EdgeInsets.symmetric(vertical: 20)),

//         // SliverAppBar #2
//         SliverAppBar(
//           elevation: 15,
//           pinned: true,
//           backgroundColor: Colors.pink,
//           expandedHeight: 250.0,
//           flexibleSpace: FlexibleSpaceBar(
//             background: Container(
//               color: Colors.amber,
//               child: const Center(
//                   child: Icon(
//                 Icons.run_circle,
//                 size: 60,
//                 color: Colors.white,
//               )),
//             ),
//             title: const Text(
//               'Featured Courses',
//               style: TextStyle(color: Colors.white),
//             ),
//           ),
//         ),

//         SliverGrid.count(
//           crossAxisCount: 2,
//           mainAxisSpacing: 10.0,
//           crossAxisSpacing: 10.0,
//           childAspectRatio: 1,
//           children: [
//             Card(
//               color: Colors.blue[200],
//               child: Container(
//                   width: 100.00,
//                   height: 100.00,
//                   decoration: new BoxDecoration(
//                     image: new DecorationImage(
//                       image: ExactAssetImage('assets/images/datascience.png'),
//                       fit: BoxFit.fitHeight,
//                     ),
//                   )),
//             ),
//             Card(
//               color: Colors.blue[400],
//               child: Container(
//                   width: 100.00,
//                   height: 100.00,
//                   decoration: new BoxDecoration(
//                     image: new DecorationImage(
//                       image: ExactAssetImage('assets/images/devops.png'),
//                       fit: BoxFit.fitHeight,
//                     ),
//                   )),
//             ),
//             Card(
//               color: Colors.blue[600],
//               child: Container(
//                   width: 100.00,
//                   height: 100.00,
//                   decoration: new BoxDecoration(
//                     image: new DecorationImage(
//                       image: ExactAssetImage('assets/images/webdev.png'),
//                       fit: BoxFit.fitHeight,
//                     ),
//                   )),
//             ),
//             Card(
//               color: Colors.blue[100],
//               child: Container(
//                   width: 100.00,
//                   height: 100.00,
//                   decoration: new BoxDecoration(
//                     image: new DecorationImage(
//                       image: ExactAssetImage('assets/images/selenium.png'),
//                       fit: BoxFit.fitHeight,
//                     ),
//                   )),
//             ),

//             // Just add some padding
//             // const SliverPadding(padding: EdgeInsets.symmetric(vertical: 20)),

//             // SliverGrid #2 (with dynamic content)
//             // SliverGrid(
//             // gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//             //   crossAxisCount: 2,
//             //   mainAxisSpacing: 10,
//             //   crossAxisSpacing: 10,
//             //   childAspectRatio: 2.0,
//             // ),
//             // delegate: SliverChildBuilderDelegate(
//             //   (context, index) {
//             //     return Card(
//             //       // generate ambers with random shades
//             //       color: Colors.amber[Random().nextInt(9) * 100],
//             //       child: Container(
//             //         alignment: Alignment.center,
//             //         decoration: new BoxDecoration(
//             //           image: new DecorationImage(
//             //             image: ExactAssetImage('assets/images/datascience.png'),
//             //             fit: BoxFit.fitHeight,
//             //           ),
//             //         ),
//             //       ),
//             //     );
//             //   },
//             //   // childCount: _gridItems.length,
//             // ),
//             //),
//           ],
//         ),
//       ]),
//     );
//   }
// }
