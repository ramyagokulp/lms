// import 'package:flutter/material.dart';

// class HomeScreen extends StatefulWidget {
//   const HomeScreen({Key? key}) : super(key: key);

//   @override
//   State<HomeScreen> createState() => _HomeScreenState();
// }

// class _HomeScreenState extends State<HomeScreen> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Center(
//         child: ListView.builder(
//           itemCount: 6,
//           scrollDirection: Axis.vertical,
//           itemBuilder: (BuildContext context, int index) {
//             return GestureDetector(
//               onTap: () {},
//               child: Padding(
//                 padding: const EdgeInsets.all(8.0),
//                 child: Container(
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     mainAxisAlignment: MainAxisAlignment.start,
//                     children: [
//                       Container(
//                         height: 100.0,
//                         width: 200.0,
//                         decoration: BoxDecoration(
//                             image: DecorationImage(
//                                 fit: BoxFit.fitWidth,
//                                 image: NetworkImage('image'))),
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(top: 8.0),
//                         child: Container(
//                           constraints: BoxConstraints(maxWidth: 220.0),
//                           child: Text(
//                             'title',
//                             style:
//                                 TextStyle(color: Colors.white, fontSize: 18.0),
//                           ),
//                         ),
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(top: 8.0),
//                         child: Text(
//                           'Author',
//                           style: TextStyle(
//                               color: Colors.grey.shade600, fontSize: 12.0),
//                         ),
//                       ),
//                       Row(
//                         children: [
//                           Icon(Icons.star, color: Colors.yellow),
//                           Icon(Icons.star, color: Colors.yellow),
//                           Icon(Icons.star, color: Colors.yellow),
//                           Icon(Icons.star, color: Colors.yellow),
//                           Icon(Icons.star, color: Colors.yellow),
//                           Padding(
//                             padding: const EdgeInsets.only(left: 4.0),
//                             child: Text(
//                               'ratings',
//                               style: TextStyle(
//                                   color: Colors.grey.shade600, fontSize: 16.0),
//                             ),
//                           ),
//                           Padding(
//                             padding: const EdgeInsets.only(left: 8.0),
//                             child: Text(
//                               ('Enrolled'),
//                               style: TextStyle(
//                                   color: Colors.grey.shade600, fontSize: 16.0),
//                             ),
//                           ),
//                         ],
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(top: 4.0),
//                         child: Row(
//                           children: [
//                             Icon(Icons.currency_rupee_outlined,
//                                 color: Colors.white),
//                             Text(
//                               'price',
//                               style: TextStyle(
//                                   color: Colors.white, fontSize: 22.0),
//                             ),
//                             // Padding(
//                             //   padding: const EdgeInsets.only(left: 4.0),
//                             //   child: Text(
//                             //     'notPrice',
//                             //     style: TextStyle(
//                             //         decoration: TextDecoration.lineThrough,
//                             //         color: Colors.grey.shade600,
//                             //         fontSize: 18.0),
//                             //   ),
//                             // ),
//                           ],
//                         ),
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(top: 4.0),
//                         child: Container(
//                           decoration: BoxDecoration(
//                             borderRadius: BorderRadius.circular(10),
//                             color: Colors.yellow,
//                           ),
//                           child: Padding(
//                             padding: const EdgeInsets.all(8.0),
//                             child: Text('Bestseller',
//                                 style: TextStyle(
//                                     color: Colors.brown,
//                                     fontWeight: FontWeight.bold)),
//                           ),
//                         ),
//                       )
//                     ],
//                   ),
//                 ),
//               ),
//             );
//           },
//         ),
//       ),
//     );
//   }
// }
