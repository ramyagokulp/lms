// import 'package:flutter/material.dart';

// class HomePages extends StatefulWidget {
//   const HomePages({Key? key}) : super(key: key);

//   @override
//   State<HomePages> createState() => _HomePagesState();
// }

// class _HomePagesState extends State<HomePages> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Learning Management System'),
//       ),
//       body: Column(
//         children: [
//           Container(
//             margin: EdgeInsets.only(left: 3, top: 11),
//             child: ListView(
//               scrollDirection: Axis.horizontal,
//               children: [
//                 Container(
//                   //color: Colors.black,
//                   // margin: EdgeInsets.only(left: 10),
//                   height: 350,
//                   width: 250,
//                   child: Padding(
//                     padding: const EdgeInsets.all(1.0),
//                     child: Column(
//                       //
//                       //mainAxisAlignment: MainAxisAlignment.start,
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Card(
//                           color: Colors.blue[200],
//                           child: Container(
//                             width: 100.00,
//                             height: 100.00,
//                             decoration: new BoxDecoration(
//                               image: new DecorationImage(
//                                 image: ExactAssetImage(
//                                     'assets/images/flutter.png'),
//                                 fit: BoxFit.fitHeight,
//                               ),
//                             ),
//                           ),
//                         ),
//                         Text("Flutter App Development",
//                             style: TextStyle(
//                               fontSize: 15,
//                               fontWeight: FontWeight.bold,
//                             ))
//                       ],
//                     ),
//                   ),
//                 ),
//                 Container(
//                   height: 350,
//                   width: 250,
//                   child: Padding(
//                     padding: const EdgeInsets.all(1.0),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Card(
//                           color: Colors.blue[200],
//                           child: Container(
//                             width: 100.00,
//                             height: 100.00,
//                             decoration: new BoxDecoration(
//                               image: new DecorationImage(
//                                 image: ExactAssetImage(
//                                     'assets/images/datascience.png'),
//                                 fit: BoxFit.fitHeight,
//                               ),
//                             ),
//                             child: Text(
//                               'DataScience',
//                               style: TextStyle(
//                                   fontWeight: FontWeight.bold, fontSize: 18),
//                             ),
//                           ),
//                         ),
//                         Text('Data Science',
//                             style: TextStyle(
//                               fontSize: 15,
//                               fontWeight: FontWeight.bold,
//                             ))
//                       ],
//                     ),
//                   ),
//                 ),
//                 Container(
//                   height: 350,
//                   width: 250,
//                   child: Padding(
//                     padding: const EdgeInsets.all(1.0),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Card(
//                           color: Colors.blue[400],
//                           child: Container(
//                               width: 100.00,
//                               height: 100.00,
//                               decoration: new BoxDecoration(
//                                 image: new DecorationImage(
//                                   image: ExactAssetImage(
//                                       'assets/images/devops.png'),
//                                   fit: BoxFit.fitHeight,
//                                 ),
//                               )),
//                         ),
//                         Text('Devops Engineering course',
//                             style: TextStyle(
//                               fontSize: 15,
//                               fontWeight: FontWeight.bold,
//                             ))
//                       ],
//                     ),
//                   ),
//                 ),
//                 Container(
//                   height: 350,
//                   width: 250,
//                   child: Padding(
//                     padding: const EdgeInsets.all(1.0),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Card(
//                           color: Colors.blue[400],
//                           child: Container(
//                               width: 100.00,
//                               height: 100.00,
//                               decoration: new BoxDecoration(
//                                 image: new DecorationImage(
//                                   image: ExactAssetImage(
//                                       'assets/images/selenium.png'),
//                                   fit: BoxFit.fitHeight,
//                                 ),
//                               )),
//                         ),
//                         Text('Selenium course',
//                             style: TextStyle(
//                               fontSize: 15,
//                               fontWeight: FontWeight.bold,
//                             ))
//                       ],
//                     ),
//                   ),
//                 ),
//                 Container(
//                   height: 350,
//                   width: 250,
//                   child: Padding(
//                     padding: const EdgeInsets.all(1.0),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Card(
//                           color: Colors.blue[400],
//                           child: Container(
//                               width: 100.00,
//                               height: 100.00,
//                               decoration: new BoxDecoration(
//                                 image: new DecorationImage(
//                                   image:
//                                       ExactAssetImage('assets/images/sql.png'),
//                                   fit: BoxFit.fitHeight,
//                                 ),
//                               )),
//                         ),
//                         Text(
//                           'SQL course',
//                           style: TextStyle(
//                             fontSize: 15,
//                             fontWeight: FontWeight.bold,
//                           ),
//                         )
//                       ],
//                     ),
//                   ),
//                 ),
//                 Container(
//                   height: 350,
//                   width: 250,
//                   child: Padding(
//                     padding: const EdgeInsets.all(1.0),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Card(
//                           color: Colors.blue[400],
//                           child: Container(
//                               width: 100.00,
//                               height: 100.00,
//                               decoration: new BoxDecoration(
//                                 image: new DecorationImage(
//                                   image: ExactAssetImage(
//                                       'assets/images/cybersecurity.png'),
//                                   fit: BoxFit.fitHeight,
//                                 ),
//                               )),
//                         ),
//                         Text('CyberSecurity course',
//                             style: TextStyle(
//                               fontSize: 15,
//                               fontWeight: FontWeight.bold,
//                             ))
//                       ],
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           ),
//           Text('Featured courses',
//               style: TextStyle(
//                 fontSize: 25,
//                 fontWeight: FontWeight.bold,
//               )),
//           Container(
//             child: ListView(
//               scrollDirection: Axis.vertical,
//               children: [
//                 Container(
//                   height: 350,
//                   width: 250,
//                   child: Padding(
//                     padding: const EdgeInsets.all(1.0),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Card(
//                           color: Colors.blue[400],
//                           child: Container(
//                               width: 100.00,
//                               height: 100.00,
//                               decoration: new BoxDecoration(
//                                 image: new DecorationImage(
//                                   image: ExactAssetImage(
//                                       'assets/images/selenium.png'),
//                                   fit: BoxFit.fitHeight,
//                                 ),
//                               )),
//                         ),
//                         Text('Selenium course')
//                       ],
//                     ),
//                   ),
//                 ),
//                 Container(
//                   height: 350,
//                   width: 250,
//                   child: Padding(
//                     padding: const EdgeInsets.all(1.0),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Card(
//                           color: Colors.blue[200],
//                           child: Container(
//                             width: 100.00,
//                             height: 100.00,
//                             decoration: new BoxDecoration(
//                               image: new DecorationImage(
//                                 image: ExactAssetImage(
//                                     'assets/images/datascience.png'),
//                                 fit: BoxFit.fitHeight,
//                               ),
//                             ),
//                             child: Text(
//                               'DataScience',
//                               style: TextStyle(
//                                   fontWeight: FontWeight.bold, fontSize: 18),
//                             ),
//                           ),
//                         ),
//                         Text('Data Science',
//                             style: TextStyle(
//                               fontSize: 15,
//                               fontWeight: FontWeight.bold,
//                             ))
//                       ],
//                     ),
//                   ),
//                 ),
//               ],
//             ),
//           )
//         ],
//       ),
//     );
//   }
// }
