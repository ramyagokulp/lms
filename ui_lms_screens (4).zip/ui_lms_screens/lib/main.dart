import 'package:bloc_pattern/bloc_pattern.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:ui_lms_screens/AuthJohny/AuthPage.dart';
import 'package:ui_lms_screens/AuthJohny/Login.dart';
import 'package:ui_lms_screens/AuthJohny/utils.dart';
import 'package:ui_lms_screens/Auth_geekyshow/login.dart';
import 'package:ui_lms_screens/AuthenticationWebfun/register.dart';
import 'package:ui_lms_screens/screens/Featured_courseScreen.dart';

import 'package:ui_lms_screens/screens/splash_screen.dart';
import 'package:get/utils.dart';
import 'package:ui_lms_screens/AuthJohny/utils.dart';

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
      options: FirebaseOptions(
          apiKey: "AIzaSyB0XhbvEHeI1a_91udC-fKH1RwnEhHddqY",
          appId: "1:251713139814:android:c49c2efcfc82f5a953e9a7",
          messagingSenderId: '',
          projectId: 'learning-mngmt-syst'));
  runApp(MyApp());
}

final navigatorKey = GlobalKey<NavigatorState>();

class MyApp extends StatelessWidget {
  final Future<FirebaseApp> _initialization = Firebase.initializeApp();
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: _initialization,
        builder: (context, snapshot) {
          // Check for Errors
          if (snapshot.hasError) {
            print("Something Went Wrong");
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          // return BlocProvider(
          //   blocs: [Bloc((i) => MovieBloc(MovieService()))],
          //   dependencies: [],
          return GetMaterialApp(
            title: 'Flutter Firebase EMail Password Auth',
            theme: ThemeData(
              primarySwatch: Colors.cyan,
            ),
            debugShowCheckedModeBanner: false,
            home: Login(),
          );
          // );
        });
  }
}

















// class MyApp extends StatelessWidget {
//   const MyApp({Key? key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       //scaffoldMessengerKey: Utils.messengerKey,
//       navigatorKey: navigatorKey,
//       debugShowCheckedModeBanner: false,
//       home: Register(),

//       //home: MainPage(),
//     );
//   }
// }

// class MainPage extends StatefulWidget {
//   const MainPage({Key? key}) : super(key: key);

//   @override
//   State<MainPage> createState() => _MainPageState();
// }

// class _MainPageState extends State<MainPage> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         body: StreamBuilder<User?>(
//             stream: FirebaseAuth.instance.authStateChanges(),
//             builder: (context, snapshot) {
//               if (snapshot.connectionState == ConnectionState.waiting) {
//                 return Center(child: CircularProgressIndicator());
//               } else if (snapshot.hasError) {
//                 return Center(child: Text('Something went wrong'));
//               } else if (snapshot.hasData) {
//                 return Featured();
//               } else {
//                 return AuthPage();
//               }
//             }));
//   }
// }
