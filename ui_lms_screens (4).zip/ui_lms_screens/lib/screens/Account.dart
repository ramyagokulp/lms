import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';

import 'package:ui_lms_screens/screens/Featured_courseScreen.dart';
import 'package:ui_lms_screens/screens/splash_screen.dart';

//Deatileddescription
class Account extends StatefulWidget {
  @override
  _AccountState createState() => _AccountState();
}

class _AccountState extends State<Account> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        // leading: IconButton(
        //     onPressed: () {
        //       Navigator.push(
        //           context, MaterialPageRoute(builder: (context) => Featured()));
        //     },
        //     icon: Icon(Icons.arrow_back_ios)),
        actions: [
          IconButton(
            icon: Icon(Icons.shopping_bag),
            onPressed: () {
              print('Basket window');
            },
          )
        ],
        backgroundColor: Colors.black,
        title: Text('Account',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 300.0,
                width: 400.0,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      'Ramya Varma',
                      style: TextStyle(color: Colors.white, fontSize: 24.0),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Icon(
                            Icons.g_mobiledata,
                            color: Colors.white,
                            size: 26,
                          ),
                          Text(
                            'ramyavarma001@gmail.com',
                            style:
                                TextStyle(color: Colors.grey, fontSize: 20.0),
                          )
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 30.0),
                      child: MaterialButton(
                        onPressed: () {},
                        child: Text(
                          'Become an instructor',
                          style: TextStyle(
                              color: Colors.lightBlue,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    )
                  ],
                ),
              ),
              Text(
                'Video preference',
                style: TextStyle(color: Colors.grey, fontSize: 14.0),
              ),
              ListTile(
                trailing: Icon(Icons.arrow_forward_ios, color: Colors.white),
                title: Text(
                  'Download Options',
                  style: TextStyle(color: Colors.white, fontSize: 20.0),
                ),
              ),
              ListTile(
                trailing: Icon(Icons.arrow_forward_ios, color: Colors.white),
                title: Text(
                  'Video Playback Options',
                  style: TextStyle(color: Colors.white, fontSize: 20.0),
                ),
              ),
              Text(
                'Account Settings',
                style: TextStyle(color: Colors.grey, fontSize: 14.0),
              ),
              ListTile(
                trailing: Icon(Icons.arrow_forward_ios, color: Colors.white),
                title: Text(
                  'Account Security',
                  style: TextStyle(color: Colors.white, fontSize: 20.0),
                ),
              ),
              ListTile(
                trailing: Icon(Icons.arrow_forward_ios, color: Colors.white),
                title: Text(
                  'Email Notification Preferences',
                  style: TextStyle(color: Colors.white, fontSize: 20.0),
                ),
              ),
              ListTile(
                trailing: Icon(Icons.arrow_forward_ios, color: Colors.white),
                title: Row(
                  children: [
                    Text(
                      'Learning Reminders',
                      style: TextStyle(color: Colors.white, fontSize: 20.0),
                    ),
                    Icon(Icons.new_releases, color: Colors.white)
                  ],
                ),
              ),
              Text(
                'Support',
                style: TextStyle(color: Colors.grey, fontSize: 14.0),
              ),
              ListTile(
                trailing: Icon(Icons.arrow_forward_ios, color: Colors.white),
                title: Text(
                  'About LMS',
                  style: TextStyle(color: Colors.white, fontSize: 20.0),
                ),
              ),
              ListTile(
                trailing: Icon(Icons.arrow_forward_ios, color: Colors.white),
                title: Text(
                  'About LMS for business',
                  style: TextStyle(color: Colors.white, fontSize: 20.0),
                ),
              ),
              ListTile(
                trailing: Icon(Icons.arrow_forward_ios, color: Colors.white),
                title: Text(
                  'FAQs',
                  style: TextStyle(color: Colors.white, fontSize: 20.0),
                ),
              ),
              Text(
                'Diagonostics',
                style: TextStyle(color: Colors.grey, fontSize: 14.0),
              ),
              ListTile(
                trailing: Icon(Icons.arrow_forward_ios, color: Colors.white),
                title: Text(
                  'Status',
                  style: TextStyle(color: Colors.white, fontSize: 20.0),
                ),
              ),
              Center(
                child: MaterialButton(
                  onPressed: () {
                    Navigator.pushReplacement(
                        context,
                        PageTransition(
                            child: SplashScreen(),
                            type: PageTransitionType.bottomToTop));
                  },
                  child: Text(
                    'Sign out',
                    style: TextStyle(color: Colors.lightBlue),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
