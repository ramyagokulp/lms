import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:ui_lms_screens/Auth_geekyshow/login.dart';
import 'package:ui_lms_screens/screens/data_controller.dart';
import 'package:video_player/video_player.dart';

class Home_Courses extends StatefulWidget {
  const Home_Courses({Key? key}) : super(key: key);

  @override
  State<Home_Courses> createState() => _Home_CoursesState();
}

class _Home_CoursesState extends State<Home_Courses> {
  final Stream<QuerySnapshot> courses =
      FirebaseFirestore.instance.collection('courses').snapshots();

  final Stream<QuerySnapshot> course_video_datascience = FirebaseFirestore
      .instance
      .collection('course_video/data_science/videos')
      .snapshots();
  final Stream<QuerySnapshot> course_video_flutter = FirebaseFirestore.instance
      .collection('course_video/Flutter/videos')
      .snapshots();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Flutter Course'), actions: [
        Padding(
          padding: const EdgeInsets.all(10.0),
          child: Container(
            child: ElevatedButton(
              onPressed: () async => {
                await FirebaseAuth.instance.signOut(),
                Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                      builder: (context) => Login(),
                    ),
                    (route) => false)
              },
              // child: Text(
              //   'Logout',
              //   style: TextStyle(
              //       color: Colors.white,
              //       fontWeight: FontWeight.bold,
              //       fontSize: 17),
              // ),
              child: Icon(
                Icons.power_settings_new_rounded,
                size: 26,
                color: Colors.white,
              ),
              style: ElevatedButton.styleFrom(primary: Colors.black),
            ),
          ),
        ),
      ]),
      body: Container(
        color: Colors.black,
        height: double.infinity,
        child: StreamBuilder<QuerySnapshot>(
          stream: course_video_flutter,
          builder:
              (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (snapshot.hasError) {
              return Text(
                'Something went wrong',
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    color: Colors.white),
              );
            }
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Text(
                'Loading.... . .  .  .',
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    color: Colors.white),
              );
            }
            final data = snapshot.requireData;
            return GridView.builder(
                shrinkWrap: true,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    //maxCrossAxisExtent: 400,
                    childAspectRatio: 3 / 2,
                    crossAxisCount: 2,
                    crossAxisSpacing: 6,
                    mainAxisSpacing: 5),
                itemCount: data.size,
                itemBuilder: (BuildContext ctx, index) {
                  return Container(
                    padding: EdgeInsets.only(top: 18),
                    child: GridTile(
                        footer: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            '${data.docs[index]['name']}',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        child: PlayVideo(videoUrl: data.docs[index]['video'])),
                  );
                  // PlayVideo(videoUrl: data.docs[index]['video']));

                  // Image.network(data.docs[index]['image']),
                  // Text('${data.docs[index]['name']}',
                  //     style: const TextStyle(
                  //         fontSize: 20, color: Colors.white),
                  //     textAlign: TextAlign.center),
                });
          },
        ),
      ),
    );
  }
}




//********** */
// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:ui_lms_screens/Auth_geekyshow/login.dart';
// import 'package:ui_lms_screens/screens/data_controller.dart';
// import 'package:video_player/video_player.dart';

// class Home_Courses extends StatefulWidget {
//   const Home_Courses({Key? key}) : super(key: key);

//   @override
//   State<Home_Courses> createState() => _Home_CoursesState();
// }

// class _Home_CoursesState extends State<Home_Courses> {
//   final Stream<QuerySnapshot> courses =
//       FirebaseFirestore.instance.collection('courses').snapshots();

//   // final Stream<QuerySnapshot> course_video = FirebaseFirestore.instance
//   //     .collection('course_video/data_science/videos')
//   //     .snapshots();
//   final Stream<QuerySnapshot> course_video = FirebaseFirestore.instance
//       .collection('course_video/Flutter/videos')
//       .snapshots();

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text('Home'), actions: [
//         Padding(
//           padding: const EdgeInsets.all(10.0),
//           child: Container(
//             height: 18.6,
//             width: 86,
//             child: ElevatedButton(
//               onPressed: () async => {
//                 await FirebaseAuth.instance.signOut(),
//                 Navigator.pushAndRemoveUntil(
//                     context,
//                     MaterialPageRoute(
//                       builder: (context) => Login(),
//                     ),
//                     (route) => false)
//               },
//               child: Text(
//                 'Logout',
//                 style: TextStyle(
//                     color: Colors.white,
//                     fontWeight: FontWeight.bold,
//                     fontSize: 17),
//               ),
//               style: ElevatedButton.styleFrom(primary: Colors.black),
//             ),
//           ),
//         ),
//       ]),
//       // body: StreamBuilder(
//       //   stream: FirebaseFirestore.instance.collection("Courses").snapshots(),
//       //   builder: (context, snapshot) {
//       //     return ListView.builder(
//       //         itemCount: snapshot.data.documents.length,
//       //         itemBuilder: (context, index) {
//       //           DocumentSnapshot courses = snapshot.data.documents[index];
//       //           return ListTile(
//       //             leading: Image.network(courses['image']),
//       //             title: Text(courses['video']),
//       //             subtitle: Text(courses['name']),
//       //           );
//       //         });
//       //   },
//       // ),

//       body: Container(
//         color: Colors.black,
//         height: double.infinity,
//         child: StreamBuilder<QuerySnapshot>(
//           stream: course_video,
//           builder:
//               (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
//             if (snapshot.hasError) {
//               return Text(
//                 'Something went wrong',
//                 style: TextStyle(
//                     fontWeight: FontWeight.bold,
//                     fontSize: 20,
//                     color: Colors.white),
//               );
//             }
//             if (snapshot.connectionState == ConnectionState.waiting) {
//               return Text(
//                 'Loading.... . .  .  .',
//                 style: TextStyle(
//                     fontWeight: FontWeight.bold,
//                     fontSize: 20,
//                     color: Colors.white),
//               );
//             }
//             final data = snapshot.requireData;
//             return ListView.builder(
//                 // shrinkWrap: true,
//                 //scrollDirection: Axis.horizontal,
//                 itemCount: data.size,
//                 itemBuilder: (context, index) {
//                   return Column(

//                       //  leading: Image.network(courses['data.name']),

//                       // leading:
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       children: [
//                         SizedBox(
//                           height: 16,
//                         ),
//                         Text(
//                           '${data.docs[index]['name']}',
//                           style: TextStyle(
//                               fontSize: 26,
//                               fontWeight: FontWeight.bold,
//                               color: Colors.white),
//                         ),
//                         // Image.network(data.docs[index]['image']),
//                         // // VideoPlayer(data.docs[index]['video']),
//                         // PlayVideo(videoUrl: data.docs[index]['video']),
//                         SizedBox(
//                           height: 10,
//                         ),
//                         Image.network(data.docs[index]['image']),
//                         // VideoPlayer(data.docs[index]['video']),
//                         SizedBox(
//                           height: 5,
//                         ),
//                         PlayVideo(videoUrl: data.docs[index]['video']),
//                         SizedBox(
//                           height: 40,
//                         ),
//                       ]);
//                 });
//           },
//         ),
//       ),
//     );
//   }
// }