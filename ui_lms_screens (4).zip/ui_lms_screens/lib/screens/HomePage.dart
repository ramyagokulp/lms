import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:ui_lms_screens/screens/Course_home.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.cyan,
        title: Text(
          'Courses Available',
          style: TextStyle(
              color: Colors.black, fontWeight: FontWeight.bold, fontSize: 26),
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.fromLTRB(9, 15, 9, 10),
          color: Colors.white,
          child: Column(
            children: [
              GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Home_Courses()));
                },
                child: Card(
                    color: Colors.deepOrangeAccent[100],
                    elevation: 56,
                    shadowColor: Colors.teal,
                    child: ListTile(
                      title: Text(
                        'DataScience',
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.black),
                      ),
                      subtitle: Container(
                        height: 150,
                        width: 200,
                        child: Image(
                            image: AssetImage('assets/images/datascience.png')),
                      ),
                      trailing: Text('Total videos: 5',
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.black)),
                    )),
              ),
              SizedBox(
                height: 10,
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Home_Courses()));
                },
                child: Card(
                    color: Colors.deepOrangeAccent[100],
                    elevation: 56,
                    shadowColor: Colors.teal,
                    child: ListTile(
                      title: Text(
                        'SQL',
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.black),
                      ),
                      subtitle: Container(
                        height: 150,
                        width: 200,
                        child:
                            Image(image: AssetImage('assets/images/sql2.png')),
                      ),
                      trailing: Text('Total videos: 5',
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.black)),
                    )),
              ),
              SizedBox(height: 10),
              GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Home_Courses()));
                },
                child: Card(
                    color: Colors.deepOrangeAccent[100],
                    elevation: 56,
                    shadowColor: Colors.teal,
                    child: ListTile(
                      title: Text(
                        'Web Development',
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.black),
                      ),
                      subtitle: Container(
                        height: 150,
                        width: 200,
                        child: Image(
                            image: AssetImage('assets/images/Webdev.png')),
                      ),
                      trailing: Text('Total videos: 5',
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.black)),
                    )),
              ),
              SizedBox(
                height: 10,
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Home_Courses()));
                },
                child: Card(
                    color: Colors.deepOrangeAccent[100],
                    elevation: 56,
                    shadowColor: Colors.teal,
                    child: ListTile(
                      title: Text(
                        'DevOps',
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.black),
                      ),
                      subtitle: Container(
                        height: 150,
                        width: 200,
                        child: Image(
                            image: AssetImage('assets/images/devops.png')),
                      ),
                      trailing: Text('Total videos: 4',
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.black)),
                    )),
              ),
              SizedBox(
                height: 10,
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Home_Courses()));
                },
                child: Card(
                    color: Colors.deepOrangeAccent[100],
                    elevation: 56,
                    shadowColor: Colors.teal,
                    child: ListTile(
                      title: Text(
                        'Selenium',
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.black),
                      ),
                      subtitle: Container(
                        height: 150,
                        width: 200,
                        child: Image(
                            image: AssetImage('assets/images/selenium.png')),
                      ),
                      trailing: Text('Total videos: 6',
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Colors.black)),
                    )),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
