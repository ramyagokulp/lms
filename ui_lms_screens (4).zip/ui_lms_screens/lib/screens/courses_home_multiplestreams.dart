import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:ui_lms_screens/Auth_geekyshow/login.dart';
import 'package:ui_lms_screens/screens/data_controller.dart';

class Home_multi_courses extends StatefulWidget {
  const Home_multi_courses({Key? key}) : super(key: key);

  @override
  State<Home_multi_courses> createState() => _Home_multi_coursesState();
}

class _Home_multi_coursesState extends State<Home_multi_courses> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Home'), actions: [
        Padding(
          padding: const EdgeInsets.all(10.0),
          child: Container(
            height: 18.6,
            width: 86,
            child: ElevatedButton(
              onPressed: () async => {
                await FirebaseAuth.instance.signOut(),
                Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                      builder: (context) => Login(),
                    ),
                    (route) => false)
              },
              child: Text(
                'Logout',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 17),
              ),
              style: ElevatedButton.styleFrom(primary: Colors.black),
            ),
          ),
        ),
      ]),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Container(height: 50, child: flutterCourse(context)),
          Container(child: datascienceCourse(context)),
        ],
      ),
    );
  }
}

final Stream<QuerySnapshot> flutter_course = FirebaseFirestore.instance
    .collection('course_video/Flutter/videos')
    .snapshots();

final Stream<QuerySnapshot> datascience_course = FirebaseFirestore.instance
    .collection('course_video/data_science/video')
    .snapshots();

Widget flutterCourse(BuildContext context) {
  // appBar: AppBar(title: Text('Home'), actions: [
  //   Padding(
  //     padding: const EdgeInsets.all(10.0),
  //     child: Container(
  //       height: 18.6,
  //       width: 86,
  //       child: ElevatedButton(
  //         onPressed: () async => {
  //           await FirebaseAuth.instance.signOut(),
  //           Navigator.pushAndRemoveUntil(
  //               context,
  //               MaterialPageRoute(
  //                 builder: (context) => Login(),
  //               ),
  //               (route) => false)
  //         },
  //         child: Text(
  //           'Logout',
  //           style: TextStyle(
  //               color: Colors.white,
  //               fontWeight: FontWeight.bold,
  //               fontSize: 17),
  //         ),
  //         style: ElevatedButton.styleFrom(primary: Colors.black),
  //       ),
  //     ),
  //   ),
  // ]),
  // body: StreamBuilder(
  //   stream: FirebaseFirestore.instance.collection("Courses").snapshots(),
  //   builder: (context, snapshot) {
  //     return ListView.builder(
  //         itemCount: snapshot.data.documents.length,
  //         itemBuilder: (context, index) {
  //           DocumentSnapshot courses = snapshot.data.documents[index];
  //           return ListTile(
  //             leading: Image.network(courses['image']),
  //             title: Text(courses['video']),
  //             subtitle: Text(courses['name']),
  //           );
  //         });
  //   },
  // ),

  return StreamBuilder<QuerySnapshot>(
    stream: flutter_course,
    builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
      if (snapshot.hasError) {
        return Text(
          'Something went wrong',
          style: TextStyle(
              fontWeight: FontWeight.bold, fontSize: 20, color: Colors.white),
        );
      }
      if (snapshot.connectionState == ConnectionState.waiting) {
        return Text(
          'Loading.... . .  .  .',
          style: TextStyle(
              fontWeight: FontWeight.bold, fontSize: 20, color: Colors.white),
        );
      }
      final data = snapshot.requireData;
      return ListView.builder(
          // shrinkWrap: true,
          //scrollDirection: Axis.horizontal,
          itemCount: data.size,
          itemBuilder: (context, index) {
            return Column(

                //  leading: Image.network(courses['data.name']),

                // leading:
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  SizedBox(
                    height: 16,
                  ),
                  Text(
                    '${data.docs[index]['name']}',
                    style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                  // Image.network(data.docs[index]['image']),
                  // // VideoPlayer(data.docs[index]['video']),
                  // PlayVideo(videoUrl: data.docs[index]['video']),
                  SizedBox(
                    height: 10,
                  ),
                  Image.network(data.docs[index]['image']),
                  // VideoPlayer(data.docs[index]['video']),
                  SizedBox(
                    height: 5,
                  ),
                  PlayVideo(videoUrl: data.docs[index]['video']),
                  SizedBox(
                    height: 40,
                  ),
                ]);
          });
    },
  );
}

Widget datascienceCourse(BuildContext context) {
  return StreamBuilder<QuerySnapshot>(
    stream: datascience_course,
    builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
      if (snapshot.hasError) {
        return Text(
          'Something went wrong',
          style: TextStyle(
              fontWeight: FontWeight.bold, fontSize: 20, color: Colors.white),
        );
      }
      if (snapshot.connectionState == ConnectionState.waiting) {
        return Text(
          'Loading.... . .  .  .',
          style: TextStyle(
              fontWeight: FontWeight.bold, fontSize: 20, color: Colors.white),
        );
      }
      final data = snapshot.requireData;
      return ListView.builder(
          // shrinkWrap: true,
          //scrollDirection: Axis.horizontal,
          itemCount: data.size,
          itemBuilder: (context, index) {
            return Column(

                //  leading: Image.network(courses['data.name']),

                // leading:
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  SizedBox(
                    height: 16,
                  ),
                  Text(
                    '${data.docs[index]['name']}',
                    style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                  // Image.network(data.docs[index]['image']),
                  // // VideoPlayer(data.docs[index]['video']),
                  // PlayVideo(videoUrl: data.docs[index]['video']),
                  SizedBox(
                    height: 10,
                  ),
                  Image.network(data.docs[index]['image']),
                  // VideoPlayer(data.docs[index]['video']),
                  SizedBox(
                    height: 5,
                  ),
                  PlayVideo(videoUrl: data.docs[index]['video']),
                  SizedBox(
                    height: 40,
                  ),
                ]);
          });
    },
  );
}
