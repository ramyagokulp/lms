import 'package:flutter/material.dart';

class Downloaded_Videos extends StatefulWidget {
  const Downloaded_Videos({Key? key}) : super(key: key);

  @override
  State<Downloaded_Videos> createState() => _Downloaded_VideosState();
}

class _Downloaded_VideosState extends State<Downloaded_Videos> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text('Downloaded Videos')),
    );
  }
}
